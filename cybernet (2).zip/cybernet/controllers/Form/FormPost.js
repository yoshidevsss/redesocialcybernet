export class FormPost {
  constructor(idForm, idTextarea, ListPost) {
    this.form = document.getElementById(idForm);
    this.textarea = document.getElementById(idTextarea);
    this.listPost = document.getElementById(ListPost);
    this.addSubmit();
  }

  formValidate(value) {
    if (
      value === "" ||
      value === null ||
      value === undefined ||
      value.length < 3
    ) {
      return false;
    }
    return true;
  }

  onSubmit(func) {
    this.form.addEventListener("submit", func);
  }

  addSubmit() {
    const handleSubmit = (event) => {
      event.preventDefault();
      if (this.formValidate(this.textarea.value)) {
        const newPost = document.createElement("li");
        newPost.classList.add("post");
        const time = this.getTime();
  
        // Criar elementos para visualizar a mídia selecionada
        const mediaContainer = document.createElement("div");
        mediaContainer.classList.add("media-container");
  
        const imageInput = this.form.querySelector('input[name="image"]');
        const gifInput = this.form.querySelector('input[name="gif"]');
        const videoInput = this.form.querySelector('input[name="video"]');
  
        // Função para adicionar mídia ao container
        const appendMedia = (input, type) => {
          if (input.files.length > 0) {
            const file = input.files[0];
            const url = URL.createObjectURL(file);
            let mediaElement;
  
            if (type === 'image' || type === 'gif') {
              mediaElement = document.createElement("img");
            } else if (type === 'video') {
              mediaElement = document.createElement("video");
              mediaElement.controls = true;
            }
  
            mediaElement.src = url;
            mediaContainer.appendChild(mediaElement);
          }
        };
  
        // Adicionar mídias selecionadas
        appendMedia(imageInput, 'image');
        appendMedia(gifInput, 'gif');
        appendMedia(videoInput, 'video');
  
        newPost.innerHTML = `
        <div class="infoUserPost">
          <div class="imgUserPost"></div>
  
          <div class="nameAndHour">
            <strong>Yoshi</strong>
            <p>${time}</p>
          </div>
        </div>
  
        <p>${this.textarea.value}</p>
        `;
  
        newPost.appendChild(mediaContainer);
  
        newPost.innerHTML += `
        <div class="actionBtnPost">
          <button type="button" class="filesPost like">
            <img src="./assets/heart.svg" alt="Curtir"> Curtir
          </button>
          <button type="button" class="filesPost comment">
            <img src="./assets/comment.svg" alt="Comentar"> Comentar
          </button>
          <button type="button" class="filesPost share">
            <img src="./assets/share.svg" alt="Compartilhar"> Compartilhar
          </button>
        </div>
        `;
  
        this.listPost.appendChild(newPost);
        this.textarea.value = "";
  
        // Limpar campos de seleção de arquivo
        imageInput.value = "";
        gifInput.value = "";
        videoInput.value = "";
      } else {
        alert("ALGUM ERRO");
      }
    };
  
    this.onSubmit(handleSubmit);
  }  

  getTime() {
    const time = new Date();
    const hour = time.getHours();
    const minutes = time.getMinutes();
    return `${hour}h ${minutes}min`;
  }
}

const postForm = new FormPost("formPost", "textarea", "posts");
