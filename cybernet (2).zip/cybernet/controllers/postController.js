const Post = require('../models/postModel');
const validator = require('validator');

// Função para criar uma nova postagem
const createPost = async (req, res) => {
  try {
    // Sanitiza o conteúdo da postagem para evitar injeção de código
    const sanitizedContent = validator.escape(req.body.content);

    // Cria uma nova postagem com o conteúdo sanitizado e o caminho do arquivo de mídia
    const newPost = new Post({
      content: sanitizedContent,
      mediaPath: req.file ? req.file.path : null,
      user: req.user._id // Relaciona a postagem ao usuário autenticado
    });

    // Salva a nova postagem no banco de dados
    await newPost.save();

    // Retorna a nova postagem com status 201 (Criado)
    res.status(201).send(newPost);
  } catch (error) {
    // Retorna um erro com status 400 (Solicitação Inválida)
    res.status(400).send({ error: 'Erro ao criar postagem.', details: error });
  }
};

// Função para obter todas as postagens
const getPosts = async (req, res) => {
  try {
    // Busca todas as postagens e popula o campo 'user' com o 'username'
    const posts = await Post.find().populate('user', 'username').exec();

    // Retorna as postagens com status 200 (OK)
    res.status(200).send(posts);
  } catch (error) {
    // Retorna um erro com status 500 (Erro Interno do Servidor)
    res.status(500).send({ error: 'Erro ao obter postagens.', details: error });
  }
};

module.exports = { createPost, getPosts };
