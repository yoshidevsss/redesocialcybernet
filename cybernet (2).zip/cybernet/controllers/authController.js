const User = require('../models/userModel');
const jwt = require('jsonwebtoken');

const register = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    const user = new User({ username, email, password });
    await user.save();

    res.status(201).send({ message: 'Usuário registrado com sucesso!' });
  } catch (error) {
    res.status(400).send({ error: 'Erro ao registrar usuário.', details: error });
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await user.comparePassword(password))) {
      return res.status(400).send({ error: 'Credenciais inválidas.' });
    }

    const token = jwt.sign({ _id: user._id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.send({ token, username: user.username });
  } catch (error) {
    res.status(400).send({ error: 'Erro ao fazer login.' });
  }
};

module.exports = { register, login };
