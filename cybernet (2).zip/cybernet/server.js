require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const winston = require('winston');
const path = require('path');
const validator = require('validator');
const authRoutes = require('./routes/authRoutes');
const postRoutes = require('./routes/postRoutes');
const { authenticateToken } = require('./middleware/authMiddleware'); // Importando o middleware
// Modelo de Comentário
const Comment = mongoose.model('Comment', new mongoose.Schema({
  content: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  post: { type: mongoose.Schema.Types.ObjectId, ref: 'Post', required: true }
}));

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3000;

// Configuração do logger com winston
const logger = winston.createLogger({
  level: 'error',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log' })
  ]
});

// Conectar ao MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Conectado ao MongoDB');
}).catch((error) => {
  console.error('Erro ao conectar ao MongoDB:', error);
});

// Configuração de Content Security Policy (CSP)
app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy", 
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline'; " +
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; " +
    "img-src 'self' data:; " +
    "connect-src 'self'; " +
    "frame-ancestors 'self'; " +
    "base-uri 'self'; " +
    "form-action 'self';"
  );
  next();
});

// Servir arquivos estáticos da pasta "views" e "uploads"
app.use(express.static(path.join(__dirname, 'views')));
app.use('/uploads', express.static('uploads'));

// Rota para servir o index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Função para criar um novo comentário
// Função para criar um novo comentário
app.post('/comments', authenticateToken, (req, res) => {
  const { content, postId } = req.body;
  
  if (!content || !postId) {
    return res.status(400).json({ error: 'Conteúdo e ID do post são obrigatórios.' });
  }

  const newComment = new Comment({
    content: validator.escape(content),
    user: req.user._id, // Associa o comentário ao usuário autenticado
    post: postId // Associa o comentário à postagem
  });

  newComment.save()
    .then(comment => res.status(201).json(comment))
    .catch(error => {
      console.error('Erro ao criar comentário:', error);
      res.status(500).json({ error: 'Erro ao criar comentário.' });
    });
});



// Função para obter comentários de uma postagem
app.get('/comments/:postId', (req, res) => {
  Comment.find({ post: req.params.postId }).populate('user', 'username').exec()
    .then(comments => res.status(200).json(comments))
    .catch(error => res.status(500).json({ error: 'Erro ao obter comentários.', details: error }));
});

// Rotas
app.use('/auth', authRoutes);
app.use('/posts', postRoutes);

// Middleware para tratamento de erros
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(500).send('Algo deu errado!');
});

// Iniciar o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
