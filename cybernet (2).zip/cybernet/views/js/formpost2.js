export class FormPost {
  constructor(idForm, idTextarea, ListPost) {
    this.form = document.getElementById(idForm);
    this.textarea = document.getElementById(idTextarea);
    this.listPost = document.getElementById(ListPost);
    this.addSubmit();
    this.loadPosts(); // Carrega as postagens ao iniciar
    this.username = localStorage.getItem('username');
    document.getElementById('username').textContent = this.username;
  }

  formValidate(value) {
    return value !== "" && value.length >= 3;
  }

  onSubmit(func) {
    this.form.addEventListener("submit", func);
  }

  addSubmit() {
    this.onSubmit((event) => {
      event.preventDefault();
      if (this.formValidate(this.textarea.value)) {
        const formData = new FormData(this.form);
        fetch('https://3720-2804-4444-3221-2b00-1118-9156-d024-a152.ngrok-free.app/posts', {
          method: 'POST',
          body: formData,
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
        .then(response => response.json())
        .then(post => {
          this.addPostToDOM(post);
          this.form.reset();
        })
        .catch(error => {
          console.error('Erro ao criar a postagem:', error);
        });
      } else {
        alert("Por favor, insira uma postagem válida.");
      }
    });
  }

  loadPosts() {
    fetch('https://3720-2804-4444-3221-2b00-1118-9156-d024-a152.ngrok-free.app/posts', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => response.json())
    .then(posts => {
      console.log('Resposta da API:', posts); // Adiciona um log para ver o que está sendo retornado
      if (Array.isArray(posts)) {
        posts.forEach(post => {
          this.addPostToDOM(post);
        });
      } else {
        console.error('Erro: A resposta não é uma lista de postagens.', posts);
      }
    })
    .catch(error => {
      console.error('Erro ao carregar postagens:', error);
    });
  }

  addPostToDOM(post) {
    const postElement = document.createElement("li");
    postElement.classList.add("post");

    const time = this.getTime(new Date(post.timestamp));
    let mediaHTML = this.getMediaElement(post.mediaPath);

    let username = post.user ? post.user.username : 'Usuário Desconhecido';

    let innerHTMLContent = `
      <div class="infoUserPost">
        <div class="imgUserPost"></div>
        <div class="nameAndHour">
          <strong>${username}</strong>
          <p>${time}</p>
        </div>
      </div>
      <p>${post.content}</p>
      ${mediaHTML || ''}
      <div class="actionBtnPost">
        <button type="button" class="filesPost like">
          <img src="./assets/heart.svg" alt="Curtir"> Curtir
        </button>
        <button type="button" class="filesPost comment">
          <img src="./assets/comment.svg" alt="Comentar"> Comentar
        </button>
        <button type="button" class="filesPost share">
          <img src="./assets/share.svg" alt="Compartilhar"> Compartilhar
        </button>
      </div>
      <div class="comments" id="comments-${post._id}" style="display: none; margin-top: 15px;">
        <input type="text" id="commentInput-${post._id}" placeholder="Adicione um comentário..." style="width: calc(100% - 60px); padding: 10px; margin-right: 10px; border: 1px solid #ccc; border-radius: 5px;" />
        <button class="btnComment" data-post-id="${post._id}" style="padding: 10px 20px; background-color: #ffc320; color: white; border: none; border-radius: 5px; cursor: pointer;">Enviar</button>
        <ul id="commentList-${post._id}" class="comment-list"></ul> <!-- Adicionado -->
      </div>
    `;

    postElement.innerHTML = innerHTMLContent;
    this.listPost.prepend(postElement);

    // Adiciona o evento de clique para o botão de comentar
    const commentButton = postElement.querySelector('.filesPost.comment');
    commentButton.addEventListener('click', () => this.toggleCommentForm(post._id));

    // Adiciona o evento de clique para o botão de enviar comentário
    const sendCommentButton = postElement.querySelector('.btnComment');
    sendCommentButton.addEventListener('click', () => this.addComment(post._id));
}

  toggleCommentForm(postId) {
    const commentForm = document.getElementById(`comments-${postId}`);
    const isHidden = commentForm.style.display === 'none';
    commentForm.style.display = isHidden ? 'block' : 'none';
  }

  loadComments(postId) {
    fetch(`https://3720-2804-4444-3221-2b00-1118-9156-d024-a152.ngrok-free.app/comments/${postId}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => response.json())
    .then(comments => {
      const commentList = document.getElementById(`commentList-${postId}`);
      commentList.innerHTML = '';
      comments.forEach(comment => {
        const commentElement = document.createElement('li');
        commentElement.textContent = `${comment.user.username}: ${comment.content}`;
        commentList.appendChild(commentElement);
      });
    })
    .catch(error => {
      console.error('Erro ao carregar comentários:', error);
    });
  }

  addComment(postId) {
    const commentInput = document.getElementById(`commentInput-${postId}`);
    const content = commentInput.value;
  
    if (content) {
      fetch('https://3720-2804-4444-3221-2b00-1118-9156-d024-a152.ngrok-free.app/comments', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ content, postId })
      })
      .then(response => {
        if (!response.ok) {
          return response.json().then(err => { throw new Error(err.error || 'Erro desconhecido'); });
        }
        return response.json();
      })
      .then(comment => {
        this.loadComments(postId);
        commentInput.value = ''; // Limpa o campo de entrada de comentários
      })
      .catch(error => {
        console.error('Erro ao adicionar comentário:', error.message);
        alert('Erro ao adicionar comentário: ' + error.message);
      });
    } else {
      alert('Por favor, escreva um comentário antes de enviar.');
    }
  }
  

  getMediaElement(mediaPath) {
    if (!mediaPath) return '';
    const url = `https://3720-2804-4444-3221-2b00-1118-9156-d024-a152.ngrok-free.app/${mediaPath}`;
    if (mediaPath.match(/\.(jpeg|jpg|gif|png)$/)) {
      return `<img src="${url}" alt="Media" />`;
    } else if (mediaPath.match(/\.(mp4|mov)$/)) {
      return `<video src="${url}" controls></video>`;
    }
  }

  getTime(date) {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}h ${minutes}min`;
  }
}

// Certifique-se de que `postForm` está no escopo global para ser acessível no `onclick`
window.postForm = new FormPost("formPost", "textarea", "posts");
