const express = require('express');
const multer = require('multer');
const { createPost, getPosts } = require('../controllers/postController');
const { authenticateToken } = require('../middleware/authMiddleware');

const router = express.Router();

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // Limite de 10MB
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif|mp4|mov/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb('Erro: Apenas imagens e vídeos são permitidos!');
    }
  }
});

router.post('/', authenticateToken, upload.single('media'), createPost);
router.get('/', authenticateToken, getPosts);

module.exports = router;
